//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	lr_start_transaction("TC_Measurements");
	truclient_step("1", "Navigate to 'http://15.125.65.106:3030/'", "snapshot=Action_1.inf");
	lr_end_transaction("TC_Measurements",0);
	truclient_step("2", "Wait 10 seconds", "snapshot=Action_2.inf");

	return 0;
}

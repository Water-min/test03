Action()
{
	web_cache_cleanup();  
	web_cleanup_cookies();
//resave
lr_start_transaction("phpbb frm str avail");

    web_url("phpbb3", 
		"URL={aut_url}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);
	
	/*lr_error_message(lr_eval_string("{REQUEST}"));
    lr_error_message(lr_eval_string("{RESPONSE}"));*/

lr_end_transaction("phpbb frm str avail", LR_AUTO);

lr_start_transaction("phpbb forum faq");

	web_url("faq.php", 
		"URL={aut_url}/faq.php", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={aut_url}/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);
	/*lr_error_message(lr_eval_string("{REQUEST}"));
	lr_error_message(lr_eval_string("{RESPONSE}"));*/

	web_url("index.php", 
		"URL={aut_url}/index.php", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={aut_url}/faq.php", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);
	/*lr_error_message(lr_eval_string("{REQUEST}"));
	lr_error_message(lr_eval_string("{RESPONSE}"));*/

lr_end_transaction("phpbb forum faq", LR_AUTO);

	return 0;
}
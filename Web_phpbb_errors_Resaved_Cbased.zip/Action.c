Action()
{

//web_add_cookie("style_cookie=null; DOMAIN=labm3am215.devlab.ad");
//web_add_cookie("phpbb3_lfab4_u=1; DOMAIN=labm3am215.devlab.ad");
//web_add_cookie("phpbb3_lfab4_k=; DOMAIN=labm3am215.devlab.ad");
//web_add_cookie("phpbb3_lfab4_sid=9930258702f7101b3d4993e5956dad64; DOMAIN=labm3am215.devlab.ad");
/*lr_start_transaction("Newtours - Pcbd error");
		web_url("newtours",
		"URL=http://newtours.demoaut.com/",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=",
		"Snapshot=t5.inf",
		"Mode=HTML",
		LAST);

lr_end_transaction("Newtours - Pcbd error", LR_FAIL);*/
lr_start_transaction("Forum error - step timeout");

	web_cache_cleanup( );  
	web_cleanup_cookies();
	web_save_header(REQUEST,"REQUEST"); 
	web_save_header(RESPONSE,"RESPONSE");
	lr_continue_on_error (1);
	web_set_timeout("STEP", "1"); 
	lr_set_debug_message(LR_MSG_CLASS_EXTENDED_LOG |             LR_MSG_CLASS_FULL_TRACE, LR_SWITCH_ON );
	web_set_option("MaxRedirectionDepth", "0", LAST ); 
	web_url("phpbb3",
		"URL={aut_url}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=",
		"Snapshot=t5.inf",
		"Mode=HTML",
		LAST);
	web_set_option("MaxRedirectionDepth", "10", LAST ); 
	lr_set_debug_message(LR_MSG_CLASS_EXTENDED_LOG |             LR_MSG_CLASS_FULL_TRACE, LR_SWITCH_OFF ); 
	
	web_set_timeout("STEP", "120"); 
	//lr_error_message(lr_eval_string("{REQUEST}"));
    //lr_error_message(lr_eval_string("{RESPONSE}"));
	
lr_end_transaction("Forum error - step timeout", LR_AUTO);
lr_start_transaction("Forum error - no web_reg_find");
lr_continue_on_error (1);
	lr_save_string(lr_get_host_name(), "HOSTNAME");
	//web_add_cookie("host={HOSTNAME}; DOMAIN=labm3am215.devlab.ad");
	//web_add_cookie("script=weberror; DOMAIN=labm3am215.devlab.ad");
	//web_save_header(REQUEST,"REQUEST"); 
	//web_save_header(RESPONSE,"RESPONSE");

	web_reg_find("Search=Body",
		"Text=Random text",
		LAST);/*non existing text in page that will be downloaded*/
	web_url("phpbb3",
		"URL={aut_url}/",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=",
		"Snapshot=t5.inf",
		"Mode=HTML",
		LAST);
	
	//lr_error_message(lr_eval_string("{REQUEST}"));
    //lr_error_message(lr_eval_string("{RESPONSE}"));

lr_end_transaction("Forum error - no web_reg_find", LR_AUTO);
lr_start_transaction("Forum error - no image");

	web_image_check("web_image_check",
		"Alt=Some image",
		LAST);/*non existent image in page that will be downloaded*/

	web_url("faq.php",
		"URL={aut_url}/faq.php",
		"Resource=0",
		"RecContentType=text/html",
		"Referer={aut_url}/",
		"Snapshot=t6.inf",
		"Mode=HTML",
		LAST);

lr_end_transaction("Forum error - no image", LR_AUTO);
lr_start_transaction("Forum error - no web_find");

	web_url("index.php",
		"URL={aut_url}/index.php",
		"Resource=0",
		"RecContentType=text/html",
		"Referer={aut_url}/faq.php",
		"Snapshot=t7.inf",
		"Mode=HTML",
		LAST);

	web_find("Text Check", 
		"RightOf=If you ", 
		"LeftOf=support", 
		"What=Home",
		LAST ); /*non existing text in downloaded page*/

	lr_error_message("This massage as extra will need to be reported");

lr_end_transaction("Forum error - no web_find", LR_AUTO);
lr_start_transaction("Forum error - auto-fail");

	web_url("viewforum.php",
		"URL={aut_url}/viewforum.php?f=3",
		"Resource=0",
		"RecContentType=text/html",
		"Referer={aut_url}/index.php",
		"Snapshot=t8.inf",
		"Mode=HTML",
		LAST);
	lr_error_message("This transaction will always fail");

lr_end_transaction("Forum error - auto-fail", LR_FAIL);
lr_start_transaction("Forum error - page 404");

	web_url("index.php",
		"URL={aut_url}/summary.php",/*non existing page*/
		"Resource=0",
		"RecContentType=text/html",
		"Referer={aut_url}/viewforum.php?f=3",
		"Snapshot=t9.inf",
		"Mode=HTML",
		LAST);

lr_end_transaction("Forum error - page 404", LR_AUTO);
lr_start_transaction("Forum error - component 404");

	
	web_url("phpbb3", 
		"URL={aut_url}/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=styles/prosilver/theme/print.css", ENDITEM, 
		"Url=styles/prosilver/template/forum_fn.js", ENDITEM, 
		"Url=style.php?id=1&lang=en", ENDITEM, 
		"Url=styles/prosilver/template/styleswitcher.js", ENDITEM, 
		"Url=styles/prosilver/theme/normal.css", ENDITEM, 
		"Url=styles/prosilver/imageset/icon_topic_latest.gif", ENDITEM, 
		"Url=styles/prosilver/theme/medium.css", ENDITEM, 
		"Url=styles/prosilver/imageset/site_logo.gif", ENDITEM, 
		"Url=styles/prosilver/theme/large.css", ENDITEM, 
		"Url=styles/prosilver/theme/images/bg_button.gif", ENDITEM, 
		"Url=styles/prosilver/theme/images/icon_faq.gif", ENDITEM, 
		"Url=styles/prosilver/theme/images/bg_header.gif", ENDITEM, 
		"Url=styles/prosilver/theme/images/icon_home.gif", ENDITEM, 
		"Url=styles/prosilver/theme/images/icon_register.gif", ENDITEM, 
		"Url=styles/prosilver/theme/images/icon_logout.gif", ENDITEM, 
		"Url=styles/prosilver/theme/images/bg_list.gif", ENDITEM, 
		"Url=styles/prosilver/theme/images/gradient.gif", ENDITEM, 
		"Url=styles/prosilver/imageset/forum_read.gif", ENDITEM, 
		"Url=styles/prosilver/theme/images/icon_textbox_search.gif", ENDITEM, 
		"Url=styles/prosilver/theme/images/corners_left.png", ENDITEM, 
		"Url=styles/prosilver/theme/images/corners_right.png", ENDITEM, 
		"Url=styles/prosilver/theme/images/icon_fontsize.gif", ENDITEM,
		"Url=styles/prosilver/theme/images/icon_fontsize2.gif", ENDITEM,/*non existing resource*/
		"Url=../favicon.ico", "Referer={aut_url}/summary.php", ENDITEM, 
		LAST);
	
lr_end_transaction("Forum error - component 404", LR_AUTO);
lr_start_transaction("Forum error - script error");
web_save_header(REQUEST,"REQUEST"); 
web_save_header(RESPONSE,"RESPONSE");

	web_cache_cleanup(); 
	web_concurrent_start(NULL);
//Resources in concurrent mode
	web_url("phpbb3",
		"URL={aut_url}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=",
		"Snapshot=t1.inf",
		"Mode=HTTP",
		LAST);
	web_url("style.php",
		"URL={aut_url}/style.php?id=1&lang=en",
		"Resource=1",
		"RecContentType=text/css",
		"Referer={aut_url}/",
		LAST);
	web_url("forum_fn.js",
		"URL={aut_url}/styles/prosilver/template/forum_fn.js",
		"Resource=1",
		"RecContentType=application/javascript",
		"Referer={aut_url}/",
		LAST);
	web_concurrent_end(NULL);


lr_end_transaction("Forum error - script error", LR_AUTO);



lr_start_transaction("Forum error - outlier transaction");

	web_url("phpbb3",
		"URL={aut_url}/",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=",
		"Snapshot=t1.inf",
		"Mode=HTTP",
		LAST);

	/* Outlier threshold should be set to 4 sec in EUM Admin for this transaction */
	lr_think_time(5);

lr_end_transaction("Forum error - outlier transaction", LR_AUTO);



return 0;
}

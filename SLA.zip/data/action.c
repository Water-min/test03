Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.1");

	web_add_cookie("guest_id=v1%3A141776578459473352; DOMAIN=twitter.com");

	web_add_cookie("_ga=GA1.2.1818480966.1417765810; DOMAIN=twitter.com");

	web_add_cookie("pid=\"v3:1418020589313569309396513\"; DOMAIN=twitter.com");

	web_url("twitter.com", 
		"URL=https://twitter.com/", 
		"Resource=0", 
		"RecContentType=text/html; charset=utf-8", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://abs.twimg.com/a/1418162186/font/rosetta-icons-Regular.eot?", ENDITEM, 
		"Url=https://abs.twimg.com/c/swift/ja/bundle/frontpage.79d55fb74bbbbc0253adc4ca41fb68d8e13e726b.js", ENDITEM, 
		"Url=https://www.google-analytics.com/analytics.js", ENDITEM, 
		"Url=https://www.google-analytics.com/r/collect?v=1&_v=j31&a=156720565&t=pageview&_s=1&dl=https%3A%2F%2Ftwitter.com%2F&dp=%2Fanon%2Ffront%2Ffront&ul=ja-jp&de=utf-8&dt=Twitter%E3%81%B8%E3%82%88%E3%81%86%E3%81%93%E3%81%9D%20-%20%E3%83%AD%E3%82%B0%E3%82%A4%E3%83%B3%E3%81%BE%E3%81%9F%E3%81%AF%E6%96%B0%E8%A6%8F%E7%99%BB%E9%8C%B2&sd=24-bit&sr=1296x815&vp=777x498&je=1&fl=12.0%20r0&_u=MACAAIQAI~&jid=1400168476&cid=1818480966.1417765810&tid=UA-30775-6&_r=1&z=1570722053", ENDITEM, 
		"Url=https://abs.twimg.com/a/1418162186/img/t1/front_page/exp_photo_set_astro_reid.jpg", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j31&a=156720565&t=event&_s=2&dl=https%3A%2F%2Ftwitter.com%2F&ul=ja-jp&de=utf-8&dt=Twitter%E3%81%B8%E3%82%88%E3%81%86%E3%81%93%E3%81%9D%20-%20%E3%83%AD%E3%82%B0%E3%82%A4%E3%83%B3%E3%81%BE%E3%81%9F%E3%81%AF%E6%96%B0%E8%A6%8F%E7%99%BB%E9%8C%B2&sd=24-bit&sr=1296x815&vp=777x498&je=1&fl=12.0%20r0&ec=button&ea=existing-user-signin&el=nav-buttons&_u=OACAAIQEI~&jid=&cid=1818480966.1417765810&tid=UA-30775-6&z=682486696", ENDITEM, 
		LAST);

	web_add_cookie("_twitter_sess=BAh7CiIKZmxhc2hJQzonQWN0aW9uQ29udHJvbGxlcjo6Rmxhc2g6OkZsYXNo%250ASGFzaHsABjoKQHVzZWR7ADoPY3JlYXRlZF9hdGwrCEZM%252F1ZKAToMY3NyZl9p%250AZCIlMzhkOTg1OTk2YzgwMDRmY2ZmYmQzYzY0NTM0YjJjYmQ6B2lkIiVkYzBl%250AOThjODkyOTQwOWJkOWIwZDk5ZTllYTE5ZjRkODoJdXNlcmkEhE5CBQ%253D%253D--ac270161c68ee72e6cbcfca9b139ca2d5995d342; DOMAIN=twitter.com");

	web_add_cookie("_gat=1; DOMAIN=twitter.com");

	web_add_cookie("remember_checked_on=1; DOMAIN=twitter.com");

	web_add_cookie("twid=\"u=88231556\"; DOMAIN=twitter.com");

	web_add_cookie("auth_token=f918f4100b835a7ae1ca5c5148c121336e6809ca; DOMAIN=twitter.com");

	web_submit_form("sessions", 
		"Ordinal=2", 
		"Snapshot=t2.inf", 
		ITEMDATA, 
		"Name=session[username_or_email]", "Value=SirDracula", ENDITEM, 
		"Name=session[password]", "Value=jamproject1985", ENDITEM, 
		"Name=remember_me", "Value=1", ENDITEM, 
		EXTRARES, 
		"Url=https://abs.twimg.com/images/themes/theme1/bg.png", "Referer=https://twitter.com/", ENDITEM, 
		"Url=https://abs.twimg.com/a/1418162186/img/t1/twitter_web_sprite_icons.png", "Referer=https://twitter.com/", ENDITEM, 
		"Url=https://abs.twimg.com/a/1418162186/img/t1/spinner-rosetta-gray-32x32.gif", "Referer=https://twitter.com/", ENDITEM, 
		LAST);

	return 0;
}
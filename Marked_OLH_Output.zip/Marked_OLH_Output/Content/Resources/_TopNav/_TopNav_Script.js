/* global $ */
$(function() {
  var VIEW = {
    local: getVar('#hp-view-local'),
    online: getVar('#hp-view-online')
  };
  var BUTTON = {
    next: {
      altText: getVar('#hp-next-alt'),
      tooltip: getVar('#hp-next-tooltip')
    },
    prev: {
      altText: getVar('#hp-previous-alt'),
      tooltip: getVar('#hp-previous-tooltip')
    },
    forward: {
      altText: getVar('#hp-forward-alt'),
      tooltip: getVar('#hp-forward-tooltip')
    },
    back: {
      altText: getVar('#hp-back-alt'),
      tooltip: getVar('#hp-back-tooltip')
    },
    highlights: {
      tooltip: getVar('#hp-highlights-tooltip')
    },
    print: {
      tooltip: getVar('#hp-print-tooltip')
    }
  };
  var SEARCH = {
    first: getVar('#hp-search-all'),
    placeholder: $('.search-field:last').attr('placeholder'),
    delay: 1400
  };
  var VERSIONLABEL = getVar('#hp-version-label');
  var VERSION = getVar('#hp-help-version');
  var DEBUG_ENABLED = true;
  var log = warn = error = function() {};
  var isIE = /*@cc_on!@*/false || !!document.documentMode;
  var UrlContentIndex = document.location.href.indexOf('Content'); //i
  var UrlContentBase = document.location.href.substring(0, UrlContentIndex); //b
  var UrlStylesheetBase = UrlContentBase + 'Content/Resources/Stylesheets/'; //p
  //var l = null;

  setDebugMode();
  //BrowserDetect.init();
  updateElements();
  updateSearchFilter();
  updateToolbar();
  updateHighlights();
  generateVersionMenu();
  generateSettingsMenu();
  responsiveDesign();
  showElements();
  $('map').imageMapResize();

  function setDebugMode() {
    if (typeof console!=='undefined') {
      log = (DEBUG_ENABLED) ? console.log.bind(console) : function() {};
      warn = (DEBUG_ENABLED) ? console.warn.bind(console) : function() {};
      error = (DEBUG_ENABLED) ? console.error.bind(console) : function() {};
    }
  }

  function updateElements() {
    log('TopNav::Ready');
    var skinName = '<span class="skin-name">'+getVar('#hp-help-name')+'</span>';
    var skinShortName = '<span class="skin-short-name">'+getVar('#hp-help-short-name')+'</span>';

    $('.logo')
      .html(skinName+skinShortName)
      .wrap('<div class="logo-wrapper"><div class="logo-inner"><p></p></div></div>');
    $('.logo-wrapper')
      .prependTo('.tab-bar');
    document.querySelector('.inner-wrap')
      .appendChild(document.querySelector('.footer'));
    $('.tab-bar .navigation-wrapper .navigation')
      .wrap('<div></div>');
    var cats = $('ul.navigation > li').length;
    $('ul.navigation > li:first-child')
      .css('margin-left', (8.25 * (6 - cats)) + '%');
    $('ul.navigation > li > a')
      .each(function() {
        this.href='#';
      });
    updateCatoriesTooltips();
    $('.other .nav-search.row.outer-row')
      .wrap('<div class="search-wrapper"></div>');
    $('.other[hpidocintopic] .search-bar.search-bar-container.needs-pie > *')
      .wrapAll('<div></div>');
    $('.other .search-wrapper')
      .appendTo('.logo-wrapper');

    $('<br>')
      .appendTo('#results-heading');
    $('#about-search')
      .appendTo('#results-heading');
    $('#hp-feedbackDimmedDiv')
      .appendTo('body');
    $('#hp-feedbackDiv')
        .appendTo('body');
/*    if ($('#TopNav.other').length)
      $('#hp-feedbackDiv')
        .appendTo('#proxy-content');
    else
      $('#hp-feedbackDiv')
        .appendTo('#contentBody');*/
/*    $('#TopNav.other img:only-child')
      .each(function() {
        var $p = $(this).parent('div,p,td');
        if ($p.length &&
           !$p.text().replace(/\s+/,'').length) 
          $p.addClass('overflow-x-only');
      });
    $('#TopNav.other #proxy-body > table, #TopNav.other #proxy-body .Responsive_Hide > table')
      .each(function() {
        $(this)
          .wrap('<div class="overflow-x-only"></div>');
      });*/
    fixResponsiveMenu('#TopNav ul.off-canvas-list li.has-submenu a');
  }
  
  function updateCatoriesTooltips() {
    setTimeout(function() {
      $('ul.navigation > li > a').each(function() {
        var $el = $(this);
        var title = $el.text();
        var $c = $el
                  .clone()
                  .css({
                    display: 'inline',
                    width: 'auto',
                    visibility: 'hidden'
                  })
                  .appendTo('body');
        
        if($c.width() > $el.width()) {
          $el.attr('data-title', title);
        } else {
          $el.removeAttr('data-title');
        }
        $c.remove();
      });
    }, 1000);
  }
  
  function fixResponsiveMenu(sel) {
    setTimeout(function() {
      $(sel)
        .on("mousedown", function() {
          console.log('Menu item clicked');
          var menu = '.left-submenu.move-right:last';
          fixResponsiveMenu(menu);
          $(menu)
            .scrollTop(0);
        });
    }, 1000);
  }

  function updateSearchFilter() {
    /* optional input attributes results=5 autocomplete=on */
    var filterText = $('.search-filter:last').html();
    $('.search-filter:last').html('<div class="search-filter-label"></div>'+filterText);
    setTimeout(function() {
      $('#TopNav.home .search-area-bar').show();
      $('.other .nav-search.row.outer-row').show();
    }, 100);

    var searchFilter = getValue('searchFilter');
    if (!searchFilter) searchFilter = SEARCH.first;

    setTimeout(function() {
      $('.search-filter:last > .search-filter-content > ul > li:first-child')
        .text(SEARCH.first);
      //setSearchLabel(searchFilter);
    }, SEARCH.delay);

    if ($('#search-clear').length && !isIE /*BrowserDetect.browser!=='Explorer'*/) {
      $('#search-clear,#search-responsive-clear')
        .hide()
        .click(function() {
          $('.search-field:last').val('');
          $('.search-field:last').attr('placeholder', SEARCH.placeholder);
          $(this).hide();
        })
        .appendTo('.search-bar:last');
      $('.search-field:last')
        .on('keyup', function() {
          log('search-field:last', $('.search-field:last').val().length);
          if ($('.search-field:last').val().length)
            $('.search-area #search-clear,.Responsive_Closed #search-clear,.Responsive_Open #search-responsive-clear').show();
          else
            $('#search-clear,#search-responsive-clear').hide();
        });
      setTimeout(function() {
        if ($('.search-field:last').val().length)
          $('.search-area #search-clear,.Responsive_Closed #search-clear,.Responsive_Open #search-responsive-clear').show();
      }, SEARCH.delay);
    }
  }

  function setSearchLabel(label) {
    if ($('.search-filter-label:last').text() !== label) {
      $('.search-filter-label:last').text(label);
      setValue('searchFilter', label);
    }

    var wFilter = $('.search-filter-label:last').width();
    if (!wFilter) {
      log('setSearchLabel::recursion:width is 0');
      setTimeout(function() {setSearchLabel(label)}, 100);
      return;
    }

    var offset = 20;
    var wAvail =
      $('.search-bar:last').width() -
      $('.search-submit:last').width() - wFilter;

    $('.search-field:last').width(wAvail-offset);
    $('.search-field:last').css('margin-left', wFilter+offset+'px');
    $('.search-field:last').attr('placeholder', SEARCH.placeholder);

    if ($('#TopNav.home .search-area-bar').css('opacity')==='0' ||
        $('#TopNav.other .search-wrapper').css('opacity')==='0') {
      $('#TopNav.other .search-wrapper')
        .css('opacity', '1');
      $('#TopNav.home .search-area-bar')
      .css('opacity', 1);
      $('.search-filter:last > .search-filter-content > ul > li').click(function() {
        setSearchLabel($(this).text());
        console.log('search-filter option clicked: ', $(this).text());
      });
    }
  }

  function updateToolbar() {
    $('#proxy-topic-toolbar')
      .appendTo('.tab-bar-section .navigation-wrapper div');

    $('.other .buttons.clearfix.topicToolbarProxy .remove-highlight-button')
      .attr('title', BUTTON.highlights.tooltip);
    $('.other .buttons.clearfix.topicToolbarProxy .print-button')
      .attr('title', BUTTON.print.tooltip);
    $('.other .buttons.clearfix.topicToolbarProxy .button')
      .each(function() {
        var $this = $(this);
        $('<span class="topic-toolbar-tooltip">'+this.title+'</span>')
          .appendTo($this);
        if (!isIE/*BrowserDetect.browser !== 'Explorer'*/) this.title = '';
        $this.addClass('tooltips');
      });
    $('.other .buttons.clearfix.topicToolbarProxy .expand-all-button')
      .click(function() {
        this.lastChild.innerHTML = this.title;
      });

    var buttons = [
      {
        class: 'next-topic-button',
        alt: BUTTON.next.altText,
        text: BUTTON.next.tooltip,
        click: function() {
          var next = $('.other #hp-sidebar-menu .sidebar li > a.selected');
          if (next.next().prop("tagName")=="UL")
            next = next.next().children('li:first').children('a:first');
          else
            next = next.parent().next().children('a:first');

          if (next.length)
            location.href = next.attr('href');
        }
      },
      {
        class: 'previous-topic-button',
        alt: BUTTON.prev.altText,
        text: BUTTON.prev.tooltip,
        click: function() {
          var prev = $('.other #hp-sidebar-menu .sidebar li > a.selected');
          if (prev.parent().prev().prop("tagName")=="LI")
            prev = prev.parent().prev().children('a:first');
          else
            prev = prev.parent().parent().prev();

          if (prev.length)
            location.href = prev.attr('href');
        }
      },
      {
        class: 'forward-button',
        alt: BUTTON.forward.altText,
        text: BUTTON.forward.tooltip,
        click: function() {window.history.forward();}
      },
      {
        class: 'back-button',
        alt: BUTTON.back.altText,
        text: BUTTON.back.tooltip,
        click: function() {window.history.back();}
      }
    ];

    for (var i=0; i<buttons.length; i++) {
      var btn = $('.other .buttons.clearfix.topicToolbarProxy .print-button').clone();
      btn.removeClass('print-button').addClass(buttons[i].class);
      btn.children('img').attr('alt', buttons[i].alt);
      btn.children('span').text(buttons[i].text);
      if (isIE/*BrowserDetect.browser === 'Explorer'*/) btn.attr('title', buttons[i].text);
      btn.click(buttons[i].click);
      btn.prependTo('.other .buttons.clearfix.topicToolbarProxy .button-group-container-left');
    }
    updateToolbarToolTips();
    $(window).resize(function() {
      updateToolbarToolTips();
    });
  }
  
  function updateToolbarToolTips()
  {
    setTimeout(function() {
      $('.other .buttons.clearfix.topicToolbarProxy .button.tooltips span')
        .each(function() {
          this.style.right = '-' + (this.offsetWidth / 2 - 12) + 'px'
      });
    }, 500);
  }

/*  $('.other #hp-sidebar-menu[class!=show-siblings] .sidebar li > a.selected')
    .parent().parent().children().each(function() {
      if (this.childNodes[0].className!=='selected')
        this.className="hidden"
    });*/

  function showElements() {
    $('.other .sidebar').removeClass('hidden');
    $('#proxy-breadcrumbs').removeClass('hidden');
    $('#proxy-body').removeClass('hidden');
    $('#proxy-topic-toolbar').removeClass('hidden');
  }

  function updateHighlights() {
    $('.home .highlight-area table td')
      .each(function(i) {
        var $imgs = $('img', this);

        if ($imgs.length) {
          var $img0 = $($imgs[0]);
          var $img1 = $($imgs[1]);

          $img0.attr('onmouseover', 'this.src="'+$img1.attr('src')+'"');
          $img0.attr('onmouseout', 'this.src="'+$img0.attr('src')+'"');
          $img1.next().attr('onmouseover', 'this.previousSibling.src="'+$img1.attr('src')+'"');
          $img1.next().attr('onmouseout', 'this.previousSibling.src="'+$img0.attr('src')+'"');
          $img1.remove();
        }
      });
  }

  function generateVersionMenu() {
    if (!VERSION) return;

    //var verMenu = $('<ul class="verLangMenu responsive"><li><span>' + VERSIONLABEL + ' ' + VERSION + '</span></li></ul>').appendTo('.logo-wrapper .logo');
    var verLangMenu = $('<ul class="verLangMenu normal"><li><span>' + VERSIONLABEL + ' ' + VERSION + '</span></li></ul>').appendTo('.logo-wrapper .logo');

    if (location.protocol !== 'file:') {
      function processVersionFile(details) {
        var verFilePath =
          details.baseURL +
          '../'.repeat(details.tryLevel) +
          details.verFileName;

        log('processVersionFile::verFilePath:',verFilePath);
        $.getScript(verFilePath)
          .done(function() {
            var vlmData = {};
            var curr = {
              ver: parts.slice(-details.tryLevel)[0],
              lang: parts.slice(-(details.tryLevel+1))[0]
            };
                
            log('processVersionFile::curr:',curr);
            for (var i=0; i<vlmPaths.length; i++) {
                parts = vlmPaths[i].split('/');

                if (!vlmData[parts[1]])
                    vlmData[parts[1]] = [];
                vlmData[parts[1]].push({'lang': parts[0], 'path': vlmPaths[i]});
            }

            if (!$.isEmptyObject(vlmData)) {
                //verMenu += '<ul>';
                $('ul.verLangMenu.normal').addClass('online');
                verLangMenu = '<ul>';
                for (var x in vlmData) {
                  verLangMenu += '<li>';
                  //verMenu += '<li>';
                  if (vlmData[x].length === 1) {
                    var item = vlmData[x].pop();
                    verLangMenu += '<a href="'+((x===curr.ver||x===vlmLatest)?'#" class="selected"':vlmBaseURL+item.path+'"')+'>'+x+'</a>';
                    //if (item.lang==='en') verMenu += '<a href="'+((x===curr.ver)?'#" class="selected"':vlmBaseURL+item.path+'"')+'>'+x+'</a>';
                  } else {
                    verLangMenu += '<a href="#"'+((x===curr.ver||x===vlmLatest)?' class="selected"':'')+'>'+x+'</a>';
                    verLangMenu += '<ul>';
                    while (vlmData[x].length) {
                      var item = vlmData[x].pop();
                      verLangMenu += '<li><a href="'+
                        (((x===curr.ver||x===vlmLatest) && item.lang===curr.lang)?'#" class="selected"':vlmBaseURL+item.path+'"')+
                        '>'+vlmLangs[item.lang]+'</a></li>';
                      //if (item.lang==='en') verMenu += '<a href="'+((x===curr.ver)?'#" class="selected"':vlmBaseURL+item.path+'"')+'>'+x+'</a>';
                    }
                    verLangMenu += '</ul>';
                  }
                  verLangMenu += '</li>';
                  //verMenu += '</li>';
                }
                verLangMenu += '</ul>';
                //verMenu += '</ul></li></ul>';
                //verMenu += '</li></ul>';
                
                //$('.logo-wrapper .logo').append(verMenu);
                $('ul.verLangMenu.normal li').append(verLangMenu);
            }
          })
          .fail(function() {
            log('processVersionFile::Next tryLevel:',details.tryLevel+1);
            if (++details.tryLevel <= details.maxLevel)
              processVersionFile(details);
          });
      }

      String.prototype.repeat = function(num) {
        return new Array(isNaN(num)? 1 : ++num).join(this);
      }
      var parts = UrlContentBase.split('/');

      processVersionFile({
        tryLevel: 2,
        maxLevel: parts.length-4,
        baseURL: UrlContentBase,
        verFileName: '_TopNav_version-language-data.js'
      });
    }
  }

  function generateSettingsMenu() {
    var switchStatus = getValue('switchStatus');
    if (switchStatus && switchStatus !== 'other') {
      addSwitch({
        switchStatus: (switchStatus === 'offline') ? VIEW.online : VIEW.local,
        switchPath: getValue('switchPath'),
        currentPath: getValue('currentPath')
      });
    }
  }
  
  function responsiveDesign() {
    $(window).resize(function() {
      if ($('body').innerWidth() > 640)
        $('.off-canvas-wrap.move-right')
          .removeClass('move-right');

      updateCatoriesTooltips();          
    });
    $('#TopNav nav.tab-bar .row.outer-row .menu-icon')
      .click(function() {
        if ($('#TopNav nav.tab-bar .row.outer-row .menu-icon').attr('aria-expanded')!=='true') {
          window.scrollTo(0,0);
        }
      });
    $('a[href^="#"][href!="#"]')
      .click(function() {
        if ($("html.web").length) return;
        console.log('clicked::bookmark, ', window.scrollY);
        setTimeout(function() {
          window.scrollTo(0,$(window).scrollTop()-80);
        }, 250);
      });
    $('#TopNav.other .search-wrapper')
      .addClass('Responsive_Closed');
    $('#search-responsive-back')
      .click(function() {
        $('#TopNav.other .search-wrapper')
          .toggleClass('Responsive_Closed Responsive_Open');
        setTimeout(function() {
          $('#search-responsive-wrapper')
            .removeClass('Responsive_Hide');
          $('#TopNav nav.tab-bar .row.outer-row .menu-icon')
            .removeClass('Responsive_Hide');
          $('#TopNav .inner-wrap .logo-wrapper a.logo')
            .removeClass('Responsive_Hide');
        }, 450);
      })
      .wrap('<div id="search-wrapper-back"></div>');
    $('#TopNav.other #search-wrapper-back')
      .appendTo('#TopNav.other .search-wrapper .search-bar');
    $('#search-responsive')
      .appendTo('.logo-wrapper')
      .wrap('<div id="search-responsive-wrapper"></div>');
    $('#search-responsive-wrapper')
      .click(function() {
        $('#search-responsive-wrapper')
          .addClass('Responsive_Hide');
        $('#TopNav nav.tab-bar .row.outer-row .menu-icon')
          .addClass('Responsive_Hide');
        $('#TopNav .inner-wrap .logo-wrapper a.logo')
          .addClass('Responsive_Hide');
        $('#TopNav.other .search-wrapper')
          .toggleClass('Responsive_Closed Responsive_Open');
      })
/*     $('#feedback-header')
      .prependTo('#TopNav #hp-feedbackDiv');
     $('#feedback-image')
      .prependTo('#TopNav #hp-feedbackDiv');
     $('#TopNav #hp-feedbackClose')
      .clone()
      .attr('id', 'hp-feedbackCloseResponsive')
      .addClass('Responsive_Hide')
      .click(function() {
        $(this).addClass('Responsive_Hide');
      })
      .appendTo('body');
     $('#TopNav #hp-feedbackCloseResponsive > img')
      .attr('src', $('#TopNav #hp-feedbackCloseResponsive > img').attr('src').replace('.png', '-responsive.svg'))
     $('a[href*=sendFeedback]')
      .click(function() {
        $('#TopNav #hp-feedbackCloseResponsive').removeClass('Responsive_Hide');
      });*/
  }

  function slideMiniTOC() {
    //$('.selected + .sub-menu').addClass('hp-hide');
    //$('.sidebar').parent().attr('id', 'hp-sidebar-panel');
    //$('.sidebar').parent().prev().attr('id', 'hp-content-panel');
    //$('.sidebar').wrap('<nav id="hp-sidebar-menu"></nav>');
  /*
    $('#hp-sidebar-menu .has-children').append('<span class="sub-menu-action"></span>');
    $('#hp-sidebar-menu .sub-menu .sub-menu').append('<li><span class="sub-menu-back"><a href="#">Back</a></span></li>');
    $('#hp-content-panel').before($('#hp-sidebar-panel')).fadeIn();
    $('#hp-sidebar-panel').fadeIn();
  */

  /*  $('#hp-sidebar-panel .selected')
      .each(function() {
        $this = $(this);
        $this.parent().addClass('selected');
        $this.parents('#hp-sidebar-menu ul').addClass('visible');
        $('#hp-sidebar-menu').height($this.parent().parent().outerHeight());
        $('.sidebar').css(
            {'left': (-220*($this.parents('#hp-sidebar-menu ul').length-1))+'px'}
          );
      });

    $('#hp-sidebar-menu .sidebar .has-children .sub-menu-action')
      .click(function() {
        var $this = $(this);
        $this.prev().addClass('visible');
        $('.sidebar').animate(
            {'left': (parseInt($('.sidebar').css('left').replace('px',''))-220)+'px'},
            400,
            'swing'
          );
        if ($('#hp-sidebar-menu').height() < $this.prev().outerHeight())
          $('#hp-sidebar-menu').height($this.prev().outerHeight());
      });
    $('#hp-sidebar-menu .sidebar .has-children .sub-menu-back')
      .click(function() {
        var $this = $(this);
        $this.parent().parent().parent().addClass('visible');
        $('.sidebar').animate(
            {'left': (parseInt($('.sidebar').css('left').replace('px',''))+220)+'px'},
            400,
            'swing',
            function() {
              $this.parent().parent().removeClass('visible');
            }
          );
        $('#hp-sidebar-menu').height($this.parent().parent().parent().parent().outerHeight());
      });*/
  }

  function addSwitch(options) {
    log('TopNav::options:', options);
    $('<div class="settings-wrapper">' +
      '<div id="hp-settings-menu">' +
      '<ul>' +
      '<li class="switchStatus">'+options.switchStatus+'</li>' +
      '</ul></div></div>')
      .appendTo('.logo-wrapper');
    $('#hp-settings-menu .switchStatus')
      .click(function() {
        log('online state: ' + (($(this).text()==='View offline') ? 'online' : 'offline'));
        var url = options.switchPath +
          '#topic=' + document.location.href.substring(UrlContentIndex) +
          '?path=' + options.currentPath;
        log('url::', url);
        document.location.replace(url);
      });
  }

  function getValue(name) {
    if (typeof(Storage) !== "undefined" && typeof(sessionStorage) !== "undefined")
      return sessionStorage[name] || null;
    else if (typeof(document.cookie) !== "undefined")
      return getCookie(name) || null;
    else
      return null;
  }

  function setValue(name, value) {
    if (typeof(Storage) !== "undefined" && typeof(sessionStorage) !== "undefined")
      sessionStorage[name] = value;
    else if (typeof(document.cookie) !== "undefined")
      setCookie(name, value, 1);
  }

  function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') c = c.substring(1);
      if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
    }
    return "";
  }

  function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires;
  }
  
  function getVar(vname) {
    return $(vname).text();
  }
});

/*var BrowserDetect = {
  init: function () {
      this.browser = this.searchString(this.dataBrowser) || "Other";
      this.version = this.searchVersion(navigator.userAgent) || this.searchVersion(navigator.appVersion) || "Unknown";
  },
  searchString: function (data) {
      for (var i = 0; i < data.length; i++) {
          var dataString = data[i].string;
          this.versionSearchString = data[i].subString;

          if (dataString.indexOf(data[i].subString) !== -1) {
              return data[i].identity;
          }
      }
  },
  searchVersion: function (dataString) {
      var index = dataString.indexOf(this.versionSearchString);
      if (index === -1) {
          return;
      }

      var rv = dataString.indexOf("rv:");
      if (this.versionSearchString === "Trident" && rv !== -1) {
          return parseFloat(dataString.substring(rv + 3));
      } else {
          return parseFloat(dataString.substring(index + this.versionSearchString.length + 1));
      }
  },
  dataBrowser: [
      {string: navigator.userAgent, subString: "Chrome", identity: "Chrome"},
      {string: navigator.userAgent, subString: "MSIE", identity: "Explorer"},
      {string: navigator.userAgent, subString: "Trident", identity: "Explorer"},
      {string: navigator.userAgent, subString: "Firefox", identity: "Firefox"},
      {string: navigator.userAgent, subString: "Safari", identity: "Safari"},
      {string: navigator.userAgent, subString: "Opera", identity: "Opera"}
  ]
};*/
Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.1");

	web_add_cookie("guest_id=v1%3A141776754103053728; DOMAIN=twitter.com");

	web_url("www.twitter.com", 
		"URL=http://www.twitter.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://abs.twimg.com/c/swift/en/bundle/frontpage.86652f62538adbc1d8fa60037ff17d0c2093bdc2.js", "Referer=https://twitter.com/", ENDITEM, 
		"Url=https://abs.twimg.com/a/1417652304/font/rosetta-icons-Regular.eot?", "Referer=https://twitter.com/", ENDITEM, 
		"Url=https://www.google-analytics.com/analytics.js", "Referer=https://twitter.com/", ENDITEM, 
		"Url=https://www.google-analytics.com/r/collect?v=1&_v=j31&a=1614331800&t=pageview&_s=1&dl=https%3A%2F%2Ftwitter.com%2F&dp=%2Fanon%2Ffront%2Ffront&ul=fr-fr&de=utf-8&dt=Welcome%20to%20Twitter%20-%20Login%20or%20Sign%20up&sd=24-bit&sr=1296x815&vp=777x498&je=1&fl=12.0%20r0&_u=MEAAAIQAI~&jid=1108718329&cid=1424872457.1417767561&tid=UA-30775-6&_r=1&z=45325126", "Referer=https://twitter.com/", ENDITEM, 
		"Url=https://abs.twimg.com/a/1417652304/img/t1/front_page/exp_photo_set_astro_reid.jpg", "Referer=https://twitter.com/", ENDITEM, 
		"Url=https://abs.twimg.com/a/1417652304/img/t1/front_page/exp_wc2014_gen_timtrueman.jpg", "Referer=https://twitter.com/", ENDITEM, 
		"Url=https://abs.twimg.com/a/1417652304/img/t1/front_page/exp_photo_set_gopro.jpg", "Referer=https://twitter.com/", ENDITEM, 
		"Url=https://abs.twimg.com/a/1417652304/img/t1/front_page/exp_wc2014_gen_couch.jpg", "Referer=https://twitter.com/", ENDITEM, 
		"Url=https://abs.twimg.com/a/1417652304/img/t1/front_page/exp_photo_set_redbull.jpg", "Referer=https://twitter.com/", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS1.1");

	web_url("fwlink", 
		"URL=https://go.microsoft.com/fwlink/?LinkId=251136", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://www.bing.com/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_url("iecompatviewlist.xml", 
		"URL=https://iecvlist.microsoft.com/IE11/1375395130872/iecompatviewlist.xml", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://ieonline.microsoft.com/iedomainsuggestions/ie11/suggestions.fr-FR", "Referer=", ENDITEM, 
		LAST);

	web_url("instrumentation.cer", 
		"URL=http://ieonline.microsoft.com/s/iess/instrumentation.cer", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://ieonline.microsoft.com/ieflipahead/ie10/rules.xml?mkt=fr-FR", "Referer=", ENDITEM, 
		LAST);

	return 0;
}